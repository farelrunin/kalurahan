<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

namespace Modules\Prodeskel\Enums;

use App\Enums\BaseEnum;

defined('BASEPATH') || exit('No direct script access allowed');

class KomoditasJasaHiburanEnum extends BaseEnum
{
    public const USAHA_JASA_DAN_PERDAGANGAN         = 1;
    public const USAHA_JASA_HIBURAN                 = 2;
    public const USAHA_JASA_GAS_LISTRIK_BBM_DAN_AIR = 3;
    public const USAHA_JASA_KETERAMPILAN            = 4;
    public const USAHA_JASA_HUKUM_DAN_KONSULTANSI   = 5;
    public const USAHA_JASA_PENGINAPAN              = 6;

    public static function all(): array
    {
        return [
            self::USAHA_JASA_DAN_PERDAGANGAN         => 'Usaha Jasa dan Perdagangan',
            self::USAHA_JASA_HIBURAN                 => 'Usaha Jasa Hiburan',
            self::USAHA_JASA_GAS_LISTRIK_BBM_DAN_AIR => 'Usaha Jasa Gas, Listrik, BBM dan Air',
            self::USAHA_JASA_KETERAMPILAN            => 'Usaha Jasa Keterampilan',
            self::USAHA_JASA_HUKUM_DAN_KONSULTANSI   => 'Usaha Jasa Hukum dan Konsultansi',
            self::USAHA_JASA_PENGINAPAN              => 'Usaha Jasa Penginapan',
        ];
    }
}
