<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

namespace Modules\Prodeskel\Enums;

use App\Enums\BaseEnum;

defined('BASEPATH') || exit('No direct script access allowed');

class KomoditasJenisTempatIbadahEnum extends BaseEnum
{
    public const JUMLAH_GEREJA_KATHOLIK          = 555;
    public const JUMLAH_GEREJA_KRISTEN_PROTESTAN = 554;
    public const JUMLAH_KLENTENG                 = 558;
    public const JUMLAH_LANGGAR_SURAU_MUSHOLA    = 553;
    public const JUMLAH_MASJID                   = 552;
    public const JUMLAH_PURA                     = 557;
    public const JUMLAH_WIHARA                   = 556;

    public static function all(): array
    {
        return [
            self::JUMLAH_GEREJA_KATHOLIK          => 'Jumlah Gereja Katholik',
            self::JUMLAH_GEREJA_KRISTEN_PROTESTAN => 'Jumlah Gereja Kristen Protestan',
            self::JUMLAH_KLENTENG                 => 'Jumlah Klenteng',
            self::JUMLAH_LANGGAR_SURAU_MUSHOLA    => 'Jumlah Langgar/Surau/Mushola',
            self::JUMLAH_MASJID                   => 'Jumlah Masjid',
            self::JUMLAH_PURA                     => 'Jumlah Pura',
            self::JUMLAH_WIHARA                   => 'Jumlah Wihara',
        ];
    }
}
