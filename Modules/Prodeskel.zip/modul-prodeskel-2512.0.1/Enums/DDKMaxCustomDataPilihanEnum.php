<?php

/*
 *
 * File ini bagian dari:
 *
 * OpenSID
 *
 * Sistem informasi desa sumber terbuka untuk memajukan desa
 *
 * Aplikasi dan source code ini dirilis berdasarkan lisensi GPL V3
 *
 * Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 *
 * Dengan ini diberikan izin, secara gratis, kepada siapa pun yang mendapatkan salinan
 * dari perangkat lunak ini dan file dokumentasi terkait ("Aplikasi Ini"), untuk diperlakukan
 * tanpa batasan, termasuk hak untuk menggunakan, menyalin, mengubah dan/atau mendistribusikan,
 * asal tunduk pada syarat berikut:
 *
 * Pemberitahuan hak cipta di atas dan pemberitahuan izin ini harus disertakan dalam
 * setiap salinan atau bagian penting Aplikasi Ini. Barang siapa yang menghapus atau menghilangkan
 * pemberitahuan ini melanggar ketentuan lisensi Aplikasi Ini.
 *
 * PERANGKAT LUNAK INI DISEDIAKAN "SEBAGAIMANA ADANYA", TANPA JAMINAN APA PUN, BAIK TERSURAT MAUPUN
 * TERSIRAT. PENULIS ATAU PEMEGANG HAK CIPTA SAMA SEKALI TIDAK BERTANGGUNG JAWAB ATAS KLAIM, KERUSAKAN ATAU
 * KEWAJIBAN APAPUN ATAS PENGGUNAAN ATAU LAINNYA TERKAIT APLIKASI INI.
 *
 * @package   OpenSID
 * @author    Tim Pengembang OpenDesa
 * @copyright Hak Cipta 2009 - 2015 Combine Resource Institution (http://lumbungkomunitas.net/)
 * @copyright Hak Cipta 2016 - 2025 Perkumpulan Desa Digital Terbuka (https://opendesa.id)
 * @license   http://www.gnu.org/licenses/gpl.html GPL V3
 * @link      https://github.com/OpenSID/OpenSID
 *
 */

namespace Modules\Prodeskel\Enums;

defined('BASEPATH') || exit('No direct script access allowed');

// NOTE : Digunakan untuk menentukan jumlah data custom pilihan yang bisa ditambahkan pada pilihan bawaan
class DDKMaxCustomDataPilihanEnum
{
    public const STATUS_KEPEMILIKAN_RUMAH    = 1;
    public const SUMBER_AIR_MINUM            = 1;
    public const KEPEMILIKAN_LAHAN           = 0;
    public const KATEGORI_PRODUKSI_TAHUN_INI = [
        'k1_6a' => 1,
        'k1_6b' => 1,
        'k1_6c' => 1,
        'k1_6d' => 1,
        'k1_6e' => 1,
        'k1_6f' => 1,
        'k1_6g' => 1,
    ];
    public const KEPEMILIKAN_JENIS_TERNAK_KELUARGA_TAHUN_INI                = 2;
    public const ALAT_PRODUKSI_BUDIDAYA_IKAN                                = 2;
    public const PEMANFAATAN_DANAU_SUNGAI_WADUK_SITU_MATA_AIR_OLEH_KELUARGA = 2;
    public const LEMBAGA_PENDIDIKAN_YANG_DIMILIKI_KELUARGA_KOMUNITAS        = 0;
    public const PENGUASAAN_ASET_TANAH_OLEH_KELUARGA                        = 0;
    public const ASET_SARANA_TRANSPORTASI_UMUM                              = 2;
    public const ASET_SARANA_PRODUKSI                                       = 1;
    public const ASET_PERUMAHAN_DINDING                                     = 2;
    public const ASET_PERUMAHAN_LANTAI                                      = 4;
    public const ASET_PERUMAHAN_ATAP                                        = 0;
    public const ASET_LAINNYA                                               = 3;
    public const KUALITAS_IBU_HAMIL                                         = 1;
    public const KUALITAS_BAYI                                              = 0;
    public const KUALITAS_TEMPAT_PERSALINAN                                 = 1;
    public const KUALITAS_PERTOLONGAN_PERSALINAN                            = 5;
    public const CAKUPAN_IMUNISASI                                          = 0;
    public const PENDERITA_SAKIT_DAN_KELAINAN                               = 3;
    public const PERILAKU_HIDUP_BERSIH_SEHAT                                = 0;
    public const POLA_MAKAN_KELUARGA                                        = 2;
    public const KEBIASAAN_BEROBAT_BILA_SAKIT                               = 1;
    public const STATUS_GIZI_BALITA                                         = 0;
    public const JENIS_PENYAKIT_ANGGOTA_KELUARGA                            = 3;
    public const KERUKUNAN                                                  = 1;
    public const PERKELAHIAN                                                = 2;
    public const PENCURIAN                                                  = 2;
    public const PENJARAHAN                                                 = 1;
    public const PERJUDIAN                                                  = 1;
    public const PEMAKAIAN_MIRAS_DAN_NARKOBA                                = 1;
    public const PEMBUNUHAN                                                 = 1;
    public const PENCULIKAN                                                 = 2;
    public const KEJAHATAN_SEKSUAL                                          = 2;
    public const KEKERASAN_DALAM_KELUARGA_ATAU_RUMAH_TANGGA                 = 1;
    public const MASALAH_KESEJAHTERAAN_KELUARGA                             = 1;

    // ANGGOTA
    public const CACAT_FISIK                                         = 1;
    public const CACAT_MENTAL                                        = 3;
    public const KEDUDUKAN_ANGGOTA_SEBAGAI_WAJIB_PAJAK_DAN_RETRIBUSI = 2;
    public const LEMBAGA_PEMERINTAHAN_YANG_DIIKUTI_ANGGOTA           = 1;
    public const LEMBAGA_KEMASYARAKATAN_YANG_DIIKUTI_ANGGOTA         = 2;
    public const LEMBAGA_EKONOMI_YANG_DIIKUTI_ANGGOTA                = 1;
    public const PRODUKSI_BAHAN_GALIAN_YANG_DIMILIKI_ANGGOTA         = 1;

    public static function semua(): array
    {
        return array_merge(self::KATEGORI_PRODUKSI_TAHUN_INI, [
            DDKEnum::KODE_STATUS_KEPEMILIKAN_RUMAH                                   => self::STATUS_KEPEMILIKAN_RUMAH,
            DDKEnum::KODE_SUMBER_AIR_MINUM                                           => self::SUMBER_AIR_MINUM,
            DDKEnum::KODE_KEPEMILIKAN_LAHAN                                          => self::KEPEMILIKAN_LAHAN,
            DDKEnum::KODE_KEPEMILIKAN_JENIS_TERNAK_KELUARGA_TAHUN_INI                => self::KEPEMILIKAN_JENIS_TERNAK_KELUARGA_TAHUN_INI,
            DDKEnum::KODE_ALAT_PRODUKSI_BUDIDAYA_IKAN                                => self::ALAT_PRODUKSI_BUDIDAYA_IKAN,
            DDKEnum::KODE_PEMANFAATAN_DANAU_SUNGAI_WADUK_SITU_MATA_AIR_OLEH_KELUARGA => self::PEMANFAATAN_DANAU_SUNGAI_WADUK_SITU_MATA_AIR_OLEH_KELUARGA,
            DDKEnum::KODE_LEMBAGA_PENDIDIKAN_YANG_DIMILIKI_KELUARGA_KOMUNITAS        => self::LEMBAGA_PENDIDIKAN_YANG_DIMILIKI_KELUARGA_KOMUNITAS,
            DDKEnum::KODE_PENGUASAAN_ASET_TANAH_OLEH_KELUARGA                        => self::PENGUASAAN_ASET_TANAH_OLEH_KELUARGA,
            DDKEnum::KODE_ASET_SARANA_TRANSPORTASI_UMUM                              => self::ASET_SARANA_TRANSPORTASI_UMUM,
            DDKEnum::KODE_ASET_SARANA_PRODUKSI                                       => self::ASET_SARANA_PRODUKSI,
            DDKEnum::KODE_ASET_PERUMAHAN_DINDING                                     => self::ASET_PERUMAHAN_DINDING,
            DDKEnum::KODE_ASET_PERUMAHAN_LANTAI                                      => self::ASET_PERUMAHAN_LANTAI,
            DDKEnum::KODE_ASET_PERUMAHAN_ATAP                                        => self::ASET_PERUMAHAN_ATAP,
            DDKEnum::KODE_ASET_LAINNYA                                               => self::ASET_LAINNYA,
            DDKEnum::KODE_KUALITAS_IBU_HAMIL                                         => self::KUALITAS_IBU_HAMIL,
            DDKEnum::KODE_KUALITAS_BAYI                                              => self::KUALITAS_BAYI,
            DDKEnum::KODE_KUALITAS_TEMPAT_PERSALINAN                                 => self::KUALITAS_TEMPAT_PERSALINAN,
            DDKEnum::KODE_KUALITAS_PERTOLONGAN_PERSALINAN                            => self::KUALITAS_PERTOLONGAN_PERSALINAN,
            DDKEnum::KODE_CAKUPAN_IMUNISASI                                          => self::CAKUPAN_IMUNISASI,
            DDKEnum::KODE_PENDERITA_SAKIT_DAN_KELAINAN                               => self::PENDERITA_SAKIT_DAN_KELAINAN,
            DDKEnum::KODE_PERILAKU_HIDUP_BERSIH_SEHAT                                => self::PERILAKU_HIDUP_BERSIH_SEHAT,
            DDKEnum::KODE_POLA_MAKAN_KELUARGA                                        => self::POLA_MAKAN_KELUARGA,
            DDKEnum::KODE_KEBIASAAN_BEROBAT_BILA_SAKIT                               => self::KEBIASAAN_BEROBAT_BILA_SAKIT,
            DDKEnum::KODE_STATUS_GIZI_BALITA                                         => self::STATUS_GIZI_BALITA,
            DDKEnum::KODE_JENIS_PENYAKIT_ANGGOTA_KELUARGA                            => self::JENIS_PENYAKIT_ANGGOTA_KELUARGA,
            DDKEnum::KODE_KERUKUNAN                                                  => self::KERUKUNAN,
            DDKEnum::KODE_PERKELAHIAN                                                => self::PERKELAHIAN,
            DDKEnum::KODE_PENCURIAN                                                  => self::PENCURIAN,
            DDKEnum::KODE_PENJARAHAN                                                 => self::PENJARAHAN,
            DDKEnum::KODE_PERJUDIAN                                                  => self::PERJUDIAN,
            DDKEnum::KODE_PEMAKAIAN_MIRAS_DAN_NARKOBA                                => self::PEMAKAIAN_MIRAS_DAN_NARKOBA,
            DDKEnum::KODE_PEMBUNUHAN                                                 => self::PEMBUNUHAN,
            DDKEnum::KODE_PENCULIKAN                                                 => self::PENCULIKAN,
            DDKEnum::KODE_KEJAHATAN_SEKSUAL                                          => self::KEJAHATAN_SEKSUAL,
            DDKEnum::KODE_KEKERASAN_DALAM_KELUARGA_ATAU_RUMAH_TANGGA                 => self::KEKERASAN_DALAM_KELUARGA_ATAU_RUMAH_TANGGA,
            DDKEnum::KODE_MASALAH_KESEJAHTERAAN_KELUARGA                             => self::MASALAH_KESEJAHTERAAN_KELUARGA,
            //  ANGGOTA
            DDKEnum::KODE_CACAT_FISIK                                         => self::CACAT_FISIK,
            DDKEnum::KODE_CACAT_MENTAL                                        => self::CACAT_MENTAL,
            DDKEnum::KODE_KEDUDUKAN_ANGGOTA_SEBAGAI_WAJIB_PAJAK_DAN_RETRIBUSI => self::KEDUDUKAN_ANGGOTA_SEBAGAI_WAJIB_PAJAK_DAN_RETRIBUSI,
            DDKEnum::KODE_LEMBAGA_KEMASYARAKATAN_YANG_DIIKUTI_ANGGOTA         => self::LEMBAGA_KEMASYARAKATAN_YANG_DIIKUTI_ANGGOTA,
            DDKEnum::KODE_LEMBAGA_EKONOMI_YANG_DIMILIKI_ANGGOTA               => self::LEMBAGA_EKONOMI_YANG_DIIKUTI_ANGGOTA,
            DDKEnum::KODE_LEMBAGA_PEMERINTAHAN_YANG_DIIKUTI_ANGGOTA           => self::LEMBAGA_PEMERINTAHAN_YANG_DIIKUTI_ANGGOTA,
            DDKEnum::KODE_PRODUKSI_BAHAN_GALIAN_YANG_DIMILIKI_ANGGOTA         => self::PRODUKSI_BAHAN_GALIAN_YANG_DIMILIKI_ANGGOTA,
        ]);
    }
}
